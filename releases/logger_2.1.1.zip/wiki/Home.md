This wiki has been broken up into the following page for easier navigation:

- [Installation](wiki/Installation)
	- All the information to install and configure Logger.
- [Logger API](wiki/Logger-API)
	- Complete Logger API documentation.
- [Best Practices](wiki/Best Practices)
	- Set of best practices and suggested code templates to use when leveraging Logger.
- [Change Logs](wiki/Change Logs)
	- Set of best practices and suggested code templates to use when leveraging Logger.