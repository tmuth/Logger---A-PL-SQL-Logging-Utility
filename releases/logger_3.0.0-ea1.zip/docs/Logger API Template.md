This is a snippet template to quickly add documentation to the Logger API library.

  - [TODO_PROC_NAME](#procedure-TODO_ANCHOR_LINK)
  - [TODO_PROC_NAME](#procedure-TODO_ANCHOR_LINK)
  - [TODO_PROC_NAME](#procedure-TODO_ANCHOR_LINK)

<a name="procedure-TODO_NAME"></a>
####TODO_NAME
TODO_DESC

#####Syntax
```sql
TODO
```

#####Parameters
<table border="0">
  <tr>
    <th>Attribute</th>
    <th>Description</th>
  </tr>
  <tr>
    <td>TODO</td>
    <td>TODO</td>
  </tr>
    <tr>
    <td>TODO</td>
    <td>TODO</td>
  </tr>
  <tr>
    <td>TODO</td>
    <td>TODO</td>
  </tr>
  <tr>
    <td>TODO</td>
    <td>TODO</td>
  </tr>
  <tr>
    <td>TODO</td>
    <td>TODO</td>
  </tr>
</table>

#####Example
```sql
TODO
```